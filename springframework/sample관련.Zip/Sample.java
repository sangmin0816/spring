package kr.co.teaspoon.dto;

import lombok.*;

@Data
public class Sample {
    private int no;
    private String name;
}
